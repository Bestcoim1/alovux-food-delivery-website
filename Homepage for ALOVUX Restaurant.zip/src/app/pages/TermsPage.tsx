export default function TermsPage() {
  return (
    <div className="bg-[#fff8f6] pt-[68px] min-h-screen">
      <div className="max-w-[900px] mx-auto px-4 sm:px-5 py-8 sm:py-12">
        <h1 className="font-display font-extrabold text-[24px] sm:text-[36px] text-[#291712] mb-8">
          Điều Khoản Sử Dụng
        </h1>

        <div className="bg-white rounded-xl p-4 sm:p-8 shadow-sm space-y-8">
          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              1. Chấp Nhận Điều Khoản
            </h2>
            <p className="text-[#5d4038] text-[16px] leading-[26px] mb-3">
              Bằng việc truy cập và sử dụng dịch vụ giao đồ ăn ALOVUX, bạn đồng ý tuân thủ các điều khoản và điều kiện được nêu trong tài liệu này. Nếu bạn không đồng ý với bất kỳ phần nào của các điều khoản này, vui lòng không sử dụng dịch vụ của chúng tôi.
            </p>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              2. Dịch Vụ Giao Đồ Ăn
            </h2>
            <p className="text-[#5d4038] text-[16px] leading-[26px] mb-3">
              ALOVUX cung cấp dịch vụ đặt và giao đồ ăn trực tuyến. Chúng tôi kết nối khách hàng với các nhà hàng và người giao hàng để đảm bảo món ăn được giao đến tận nơi một cách nhanh chóng và an toàn.
            </p>
            <p className="text-[#5d4038] text-[16px] leading-[26px]">
              Thời gian giao hàng có thể thay đổi tùy thuộc vào khoảng cách, điều kiện giao thông và số lượng đơn hàng. ALOVUX không chịu trách nhiệm về sự chậm trễ do các yếu tố ngoài tầm kiểm soát.
            </p>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              3. Đặt Hàng và Thanh Toán
            </h2>
            <div className="space-y-3">
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>3.1. Đặt hàng:</strong> Khách hàng cần cung cấp đầy đủ thông tin chính xác khi đặt hàng, bao gồm địa chỉ giao hàng, số điện thoại liên hệ và yêu cầu đặc biệt (nếu có).
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>3.2. Thanh toán:</strong> ALOVUX chấp nhận nhiều hình thức thanh toán bao gồm tiền mặt khi nhận hàng (COD), thẻ tín dụng/ghi nợ, và ví điện tử. Tất cả các giao dịch được mã hóa và bảo mật.
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>3.3. Xác nhận đơn hàng:</strong> Sau khi đặt hàng thành công, bạn sẽ nhận được email hoặc thông báo xác nhận. Vui lòng kiểm tra thông tin đơn hàng ngay lập tức.
              </p>
            </div>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              4. Hủy Đơn và Hoàn Tiền
            </h2>
            <div className="space-y-3">
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>4.1. Hủy đơn hàng:</strong> Khách hàng có thể hủy đơn hàng miễn phí trước khi nhà hàng xác nhận và bắt đầu chuẩn bị món ăn. Sau thời điểm này, việc hủy đơn có thể phát sinh phí.
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>4.2. Hoàn tiền:</strong> Nếu có vấn đề với đơn hàng (món ăn sai, chất lượng không đảm bảo, giao hàng quá muộn), vui lòng liên hệ bộ phận chăm sóc khách hàng trong vòng 24 giờ. Chúng tôi sẽ xem xét và xử lý hoàn tiền hoặc đổi món trong trường hợp hợp lệ.
              </p>
            </div>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              5. Quyền và Trách Nhiệm Của Khách Hàng
            </h2>
            <div className="space-y-3">
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>5.1. Thông tin chính xác:</strong> Khách hàng có trách nhiệm cung cấp thông tin chính xác và đầy đủ khi đăng ký tài khoản và đặt hàng.
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>5.2. Bảo mật tài khoản:</strong> Khách hàng chịu trách nhiệm bảo mật thông tin đăng nhập và thông báo ngay cho ALOVUX nếu phát hiện tài khoản bị sử dụng trái phép.
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>5.3. Hành vi phù hợp:</strong> Khách hàng cam kết không sử dụng dịch vụ cho mục đích bất hợp pháp hoặc vi phạm quyền lợi của người khác.
              </p>
            </div>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              6. Trách Nhiệm Của ALOVUX
            </h2>
            <div className="space-y-3">
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>6.1. Chất lượng món ăn:</strong> ALOVUX làm việc với các nhà hàng đối tác uy tín để đảm bảo chất lượng món ăn. Tuy nhiên, chúng tôi không chịu trách nhiệm về chất lượng món ăn do nhà hàng chuẩn bị.
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>6.2. Giao hàng:</strong> Chúng tôi nỗ lực đảm bảo giao hàng đúng hẹn nhưng không chịu trách nhiệm về sự chậm trễ do các yếu tố bất khả kháng như thời tiết, tai nạn giao thông, hoặc thiên tai.
              </p>
              <p className="text-[#5d4038] text-[16px] leading-[26px]">
                <strong>6.3. Bảo mật thông tin:</strong> ALOVUX cam kết bảo vệ thông tin cá nhân của khách hàng theo chính sách bảo mật được công bố.
              </p>
            </div>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              7. Chương Trình Khuyến Mãi
            </h2>
            <p className="text-[#5d4038] text-[16px] leading-[26px] mb-3">
              Các chương trình khuyến mãi, mã giảm giá có thể có điều kiện và thời hạn áp dụng riêng. ALOVUX có quyền thay đổi hoặc hủy bỏ các chương trình khuyến mãi mà không cần thông báo trước.
            </p>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              8. Giới Hạn Trách Nhiệm
            </h2>
            <p className="text-[#5d4038] text-[16px] leading-[26px] mb-3">
              ALOVUX không chịu trách nhiệm đối với bất kỳ thiệt hại gián tiếp, ngẫu nhiên, hoặc hậu quả phát sinh từ việc sử dụng hoặc không thể sử dụng dịch vụ của chúng tôi.
            </p>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              9. Thay Đổi Điều Khoản
            </h2>
            <p className="text-[#5d4038] text-[16px] leading-[26px] mb-3">
              ALOVUX có quyền sửa đổi các điều khoản sử dụng này bất kỳ lúc nào. Các thay đổi sẽ có hiệu lực ngay khi được đăng tải trên website. Việc tiếp tục sử dụng dịch vụ sau khi có thay đổi đồng nghĩa với việc bạn chấp nhận các điều khoản mới.
            </p>
          </section>

          <section>
            <h2 className="font-display font-bold text-[18px] sm:text-[24px] text-[#291712] mb-4">
              10. Liên Hệ
            </h2>
            <p className="text-[#5d4038] text-[16px] leading-[26px] mb-3">
              Nếu bạn có bất kỳ câu hỏi nào về Điều khoản sử dụng này, vui lòng liên hệ với chúng tôi qua:
            </p>
            <div className="bg-[#fff8f6] rounded-lg p-4 space-y-2">
              <p className="text-[#5d4038] text-[16px]">
                <strong>Email:</strong> support@alovux.vn
              </p>
              <p className="text-[#5d4038] text-[16px]">
                <strong>Hotline:</strong> 1900-xxxx-xx
              </p>
              <p className="text-[#5d4038] text-[16px]">
                <strong>Địa chỉ:</strong> 123 Đường ABC, Quận 1, TP. Hồ Chí Minh
              </p>
            </div>
          </section>

          <div className="mt-8 pt-6 border-t border-[#fddbd3]">
            <p className="text-[#5d4038] text-[14px] italic">
              Điều khoản sử dụng này được cập nhật lần cuối vào ngày 25/05/2026.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
