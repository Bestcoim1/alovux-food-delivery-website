import { createContext, useContext, useState, ReactNode, useEffect } from "react";

interface User {
  name: string;
  email: string;
  phone: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, phone: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem("alovux_user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    const savedCredentials = localStorage.getItem("alovux_credentials");
    if (savedCredentials) {
      const credentials = JSON.parse(savedCredentials);
      if (credentials.email === email && credentials.password === password) {
        const userData = {
          name: credentials.name,
          email: credentials.email,
          phone: credentials.phone,
        };
        setUser(userData);
        localStorage.setItem("alovux_user", JSON.stringify(userData));
        return true;
      }
    }
    return false;
  };

  const register = (name: string, email: string, phone: string, password: string): boolean => {
    const credentials = { name, email, phone, password };
    localStorage.setItem("alovux_credentials", JSON.stringify(credentials));

    const userData = { name, email, phone };
    setUser(userData);
    localStorage.setItem("alovux_user", JSON.stringify(userData));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("alovux_user");
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
